rm -f assignment2.zip 
zip -r assignment2.zip "q4_schedule.py" "q5_linear_torch.py" "q6_nature_torch.py"
